package com.example.pricechecker;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends AppCompatActivity {

        Button bt_scan;
        Button bt_productlist;
        Button bt_about;

        String barcode; // will be passed parameter.

    public static final String EXTRA_TEXT = "com.example.pricechecker.EXTRA_TEXT";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt_scan = findViewById(R.id.scanbarcode);
        bt_productlist = (Button) findViewById(R.id.productlist);
        bt_about = (Button) findViewById(R.id.about);

        bt_productlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if(barcode !=null) {
                    openProductList();
                }
            }
        });

        bt_about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                openAbout();
            }
        });

        bt_scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                IntentIntegrator intentIntegrator = new IntentIntegrator(
                        MainActivity.this);

                intentIntegrator.setPrompt("For flash use volume up button!");
                intentIntegrator.setBeepEnabled(true);
                intentIntegrator.setOrientationLocked(true);
                intentIntegrator.setCaptureActivity(Capture.class);
                intentIntegrator.initiateScan();

            }
        });

    }
    public void openProductList() {
        Intent intent = new Intent(this, ProductList.class);
        intent.putExtra(EXTRA_TEXT,barcode);
        startActivity(intent);
    }

    public void openAbout() {
        Intent intent2 = new Intent(this, About.class);
        startActivity(intent2);
    }

    @Override
    protected  void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        IntentResult intentResult = IntentIntegrator.parseActivityResult(
                requestCode, resultCode, data);
                 barcode =  intentResult.getContents().toString();

        if (intentResult.getContents() != null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(
            MainActivity.this);


            builder.setTitle("Barcode");
            builder.setMessage(intentResult.getContents());
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });

            builder.show();
        }
        else {
            Toast.makeText(getApplicationContext()
            , "Nothing found.",Toast.LENGTH_SHORT).show();
        }
    }

}