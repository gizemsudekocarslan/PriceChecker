package com.example.pricechecker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telecom.Call;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParserException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
public class ProductList extends AppCompatActivity {

    Button bt_back;


    String barcode;
    String mystring;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);

        bt_back = (Button) findViewById(R.id.back);

        Intent intent = getIntent();
        barcode = intent.getStringExtra(MainActivity.EXTRA_TEXT);

        TextView textView1 = (TextView) findViewById(R.id.barcode_number);
        textView1.setText(barcode);



        new HTTPAsyncTask().execute("https://app.zenserp.com/api/v2/search?apikey= ac9283f0-5282-11eb-bc47-31af5279b4c4&q="+barcode+"&tbm=shop&search_engine=google.com&location=Istanbul%2CTurkey&gl=TR&hl=tr&num=10" );
        //new HTTPAsyncTask().execute("https://app.zenserp.com/api/v2/search?apikey=425f7c20-5277-11eb-b20b-4740251b4c1e&q="+barcode+"&tbm=shop&search_engine=google.com&location=Istanbul%2CTurkey&gl=TR&hl=tr&num=100" );


        bt_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                openMainActivity();
            }
        });
    }

    public void openMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private class HTTPAsyncTask extends AsyncTask<String,Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            try {


                return HttpGet(urls[0]);


            } catch (IOException e) {
                return "Unable to retrive web page. URL may be invalid.";
            }

        }


        @Override
        protected void onPostExecute(String result) {
            mystring = result;
            //!!!!!!!!! Parser
            try {

                MyJsonParser();
            } catch (XmlPullParserException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        private String HttpGet(String myUrl) throws IOException {

            InputStream inStream = null;
            String result = "";

            URL url = new URL(myUrl);
            HttpURLConnection connect = (HttpURLConnection) url.openConnection();

            connect.connect();

            inStream = connect.getInputStream();

            if (inStream != null) {
                result = convertInputToString(inStream);
            } else {
                result = "Didn't work!";
            }
            return result;
        }

        private String convertInputToString(InputStream inStream) throws IOException {
            BufferedReader reader = new BufferedReader(new InputStreamReader(inStream));
            String line = "";
            String result = "";


            while ((line = reader.readLine()) != null) {
                result += line;
            }
            return result;
        }
    }

    public void MyJsonParser() throws XmlPullParserException, IOException, JSONException {

        JSONObject reader = new JSONObject(mystring);
        JSONArray shopping_results = new JSONArray(reader.getString("shopping_results"));
        //JSONArray image_results= new JSONArray(reader.getString("image_results"));

        TextView product_name = (TextView) findViewById(R.id.product);
        TextView shop_name = (TextView) findViewById(R.id.shop);
        TextView product_price = (TextView) findViewById(R.id.price);
        TextView number = (TextView) findViewById(R.id.number);
        TextView space1 = (TextView) findViewById(R.id.space1) ;
        TextView space2 = (TextView) findViewById(R.id.space2);
        ImageView image = findViewById(R.id.imageView);

        String productname;
        String price;
        String shop;
        String thumbnail;

        thumbnail =shopping_results.getJSONObject(0).getString("thumbnail");


        productname = shopping_results.getJSONObject(0).getString("title");
        product_name.setText(productname);

        for(int i = 0;i < shopping_results.length()-1;i++){
            JSONObject result =shopping_results.getJSONObject(i);
            price = result.getString("price");
            shop = result.getString("source");

            number.append(i+1+". "+"\n\n");
            space1.append("\t\t\t\t\n\n");
            shop_name.append(shop+"\n\n");
            space2.append("\t\t\t\t\n\n");
            product_price.append(price+"\n\n");
        }

        JSONObject result =shopping_results.getJSONObject(shopping_results.length()-1);
        price = result.getString("price");
        shop = result.getString("source");


        number.append(shopping_results.length()+". ");
        space1.append("\t\t\t\t");
        shop_name.append(shop);
        space2.append("\t\t\t\t");
        product_price.append(price);

        byte[] decodedString = Base64.decode(thumbnail.substring(thumbnail.indexOf(",")  + 1), Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        image.setImageBitmap(decodedByte);

        }


}