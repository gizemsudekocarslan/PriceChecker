package com.example.pricechecker;

import com.journeyapps.barcodescanner.CaptureActivity;

public class Capture extends CaptureActivity {
}
//      android:background="@drawable/frame" bunu imageviewa eklemeyi unutmaaaaaaaaaaaaaaa